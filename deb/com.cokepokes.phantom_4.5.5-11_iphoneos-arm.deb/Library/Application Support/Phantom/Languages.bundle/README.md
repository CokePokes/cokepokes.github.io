# Phantom-Languages
Current language files packaged within Phantom

Rules:

0. Have Phantom 4.4.3-2 or higher installed on device

1. EDIT RIGHT SIDE OF =  (ex. hello = make edit here to spanish hola)

2. Retain capitalization for feature titles for instance "Camera Timer"

3. DO NOT DELETE %@ or \n or symbols similar. \n is a newline. %@ is where a word or value is placed. \'s go before quotations

4. DO NOT RE-ARRANGE order of list


Directions:

1. Download/Clone repo & make changes

2. Test by creating appropriate folder (ie: fr.lproj for french) & transfer to device at /Library/Application Support/Phantom/Languages.bundle then switch system language to new lang (ie: French)

3. Email file to cokepokes@gmail.com if tested & working correctly


